# Jev vs LLM: invoice demo

Two small Python scripts that check the same vendor invoice.

- `without_jev.py` sends everything to one LLM call.
- `with_jev.py` asks Jev for the decisions and calls the LLM only to write the message.

All names and numbers in `invoice.py` are made up.

## What you need

- Python 3.10 or newer
- VS Code with the Python extension
- A TypeSafe API key from https://console.typesafe.ai/keys (Jev is in early access)
- A Groq API key from https://console.groq.com/keys (free tier works)

## Setup in VS Code

Open this folder in VS Code, then open a terminal (Terminal, New Terminal).

On Windows (PowerShell):

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

On macOS or Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Open `.env` and paste your two keys.

## Run it

```bash
python without_jev.py
python with_jev.py
```

Both use the duplicate invoice by default. Add `--clean` to try a normal invoice:

```bash
python without_jev.py --clean
python with_jev.py --clean
```

## What to look for

- Without Jev, the LLM runs on every invoice and your code has to parse and check its JSON.
- With Jev, the clean invoice needs no LLM call at all.
- With Jev, the duplicate invoice gets decisions with probabilities, a small handoff to the LLM and a policy check on the draft.
- Compare the time and the number of LLM calls printed at the end of each run.

Your numbers will vary from run to run.
