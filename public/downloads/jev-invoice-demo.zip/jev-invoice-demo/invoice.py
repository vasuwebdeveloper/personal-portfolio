# Sample data for the demo. All names and numbers are made up.

# Invoices our AP team has already paid.
PAID_INVOICES = [
    {
        "invoice_number": "INV-2291",
        "vendor": "Northwind Supplies",
        "amount": 4860.00,
        "po_number": "PO-7741",
        "paid_on": "2026-03-12",
    },
    {
        "invoice_number": "INV-2240",
        "vendor": "Northwind Supplies",
        "amount": 1275.50,
        "po_number": "PO-7702",
        "paid_on": "2026-02-20",
    },
]

# A new invoice that repeats one we already paid.
DUPLICATE_INVOICE = {
    "invoice_number": "INV-2291",
    "vendor": "Northwind Supplies",
    "amount": 4860.00,
    "po_number": "PO-7741",
    "lines": ["Printer paper, 40 boxes", "Desk organisers, 25 units"],
    "vendor_note": "Resubmitting the March invoice, please process.",
}

# A normal new invoice with nothing unusual.
CLEAN_INVOICE = {
    "invoice_number": "INV-2317",
    "vendor": "Northwind Supplies",
    "amount": 932.40,
    "po_number": "PO-7790",
    "lines": ["Whiteboard markers, 60 packs", "Sticky notes, 30 packs"],
    "vendor_note": "September order as per PO-7790.",
}


def pick_invoice(args):
    """Use the clean invoice when the script is run with --clean."""
    if "--clean" in args:
        return CLEAN_INVOICE
    return DUPLICATE_INVOICE
