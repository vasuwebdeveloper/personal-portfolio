# With Jev: Jev makes the decisions, our code applies the rules,
# and the LLM is called only when a person needs to read something.
# Run:  python with_jev.py          (duplicate invoice)
#       python with_jev.py --clean  (normal invoice)

import json
import os
import sys
import time

from dotenv import load_dotenv
from openai import OpenAI
from typesafe_sdk import Choice, Noul, Score, TypeSafeClient

from invoice import PAID_INVOICES, pick_invoice

load_dotenv()

llm = OpenAI(
    api_key=os.environ["GROQ_API_KEY"],
    base_url="https://api.groq.com/openai/v1",
)
LLM_MODEL = "openai/gpt-oss-20b"

# Our business rules. These stay in code.
DUPLICATE_LIMIT = 0.90   # hold payment at or above this
RISK_LIMIT = 1.5         # risk score runs from 0 (Low) to 2 (High)
CONFIDENCE_MIN = 0.80    # below this, a person should check the category

new_invoice = pick_invoice(sys.argv)
state = {"new_invoice": new_invoice, "paid_invoices": PAID_INVOICES}

# Step 1: ask Jev three questions with fixed answers.
questions = {
    "category": Choice(
        instructions="Which spend category does the new invoice belong to?",
        criteria={
            "Office supplies": "Paper, stationery and desk items",
            "IT hardware": "Laptops, monitors and network equipment",
            "Facilities": "Cleaning, repairs, rent and utilities",
        },
    ),
    "risk": Score(
        instructions="How risky is it to pay the new invoice?",
        criteria=[
            "Low: known vendor, matches the PO, nothing unusual",
            "Medium: a small mismatch or something to check",
            "High: likely duplicate, wrong amount or unusual request",
        ],
    ),
    "duplicate": Noul(
        instructions="The new invoice matches an invoice in paid_invoices "
        "and has already been paid.",
    ),
}

print(f"\nInvoice {new_invoice['invoice_number']}: asking Jev three questions...")
start = time.perf_counter()
with TypeSafeClient() as jev:
    response = jev.system_one(state=state, questions=questions)
jev_seconds = time.perf_counter() - start

category = response.answers["category"]
risk = response.answers["risk"]
duplicate = response.answers["duplicate"]

print("\n--- Jev answers (ready to use, no parsing) ---")
print(f"Category:   {category.choice}   confidence {category.confidence:.2f}")
rounded = {label: round(p, 2) for label, p in category.probabilities.items()}
print(f"            probabilities {rounded}")
print(f"Risk score: {risk.score:.2f} out of 2   confidence {risk.confidence:.2f}")
print(f"Duplicate:  P(yes) = {duplicate.noul:.2f}")
print(f"Jev time:   {jev_seconds:.2f} s")

# Step 2: our code applies the rules.
reasons = []
if duplicate.noul >= DUPLICATE_LIMIT:
    reasons.append("likely duplicate")
if risk.score >= RISK_LIMIT:
    reasons.append("high payment risk")
if category.confidence < CONFIDENCE_MIN:
    reasons.append("category unclear")

if not reasons:
    print("\nDecision: clean invoice. Approve for payment.")
    print(f"\nLLM calls: 0   Total time: {jev_seconds:.2f} s")
    sys.exit(0)

print(f"\nDecision: hold payment. Reasons: {', '.join(reasons)}.")

# Step 3: build a small handoff for the LLM from Jev's answers.
handoff = {
    "invoice": new_invoice["invoice_number"],
    "vendor": new_invoice["vendor"],
    "amount": new_invoice["amount"],
    "category": f"{category.choice} ({category.confidence:.2f})",
    "risk_score": f"{risk.score:.2f} out of 2",
    "duplicate_probability": round(duplicate.noul, 2),
    "hold_reasons": reasons,
    "task": "Write a short AP review note and a polite email to the vendor.",
}

print("\n--- Handoff sent to the LLM ---")
print(json.dumps(handoff, indent=2))

# Step 4: the LLM only writes.
start = time.perf_counter()
reply = llm.chat.completions.create(
    model=LLM_MODEL,
    messages=[
        {
            "role": "system",
            "content": "You write short, polite accounts payable messages. "
            "Use only the facts you are given.",
        },
        {"role": "user", "content": json.dumps(handoff)},
    ],
)
llm_seconds = time.perf_counter() - start
draft = reply.choices[0].message.content

print("\n--- LLM draft ---")
print(draft)

# Step 5: Jev checks the draft against our policy.
start = time.perf_counter()
with TypeSafeClient() as jev:
    check = jev.system_one(
        state={"facts": handoff, "draft": draft},
        questions={
            "follows_policy": Noul(
                instructions="The draft is polite, uses only the facts given, "
                "does not promise payment, and asks the vendor to confirm "
                "or send a credit note.",
            )
        },
    )
check_seconds = time.perf_counter() - start
policy = check.answers["follows_policy"].noul

print("\n--- Policy check by Jev ---")
print(f"Follows policy: P(yes) = {policy:.2f}")
if policy >= 0.8:
    print("Send the draft to the AP reviewer for approval.")
else:
    print("Send the case to a person to rewrite.")

total = jev_seconds + llm_seconds + check_seconds
print(f"\nLLM calls: 1   Jev calls: 2   Total time: {total:.2f} s")
