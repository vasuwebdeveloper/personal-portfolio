# Without Jev: one LLM call does every step for every invoice.
# Run:  python without_jev.py          (duplicate invoice)
#       python without_jev.py --clean  (normal invoice)

import json
import os
import sys
import time

from dotenv import load_dotenv
from openai import OpenAI

from invoice import PAID_INVOICES, pick_invoice

load_dotenv()

llm = OpenAI(
    api_key=os.environ["GROQ_API_KEY"],
    base_url="https://api.groq.com/openai/v1",
)
LLM_MODEL = "openai/gpt-oss-20b"

new_invoice = pick_invoice(sys.argv)

# Step 1: ask the LLM to do everything in one prompt.
prompt = f"""You are an accounts payable assistant.
Check the new invoice against the invoices we already paid.
Reply with JSON only, using exactly these keys:
  "category": one of "Office supplies", "IT hardware", "Facilities"
  "risk": one of "Low", "Medium", "High"
  "duplicate": true or false
  "ap_note": a short note for the AP reviewer
  "vendor_email": a short email to the vendor, or "" if none is needed

New invoice:
{json.dumps(new_invoice, indent=2)}

Invoices already paid:
{json.dumps(PAID_INVOICES, indent=2)}
"""

print(f"\nInvoice {new_invoice['invoice_number']}: sending everything to the LLM...")
start = time.perf_counter()
reply = llm.chat.completions.create(
    model=LLM_MODEL,
    messages=[{"role": "user", "content": prompt}],
    response_format={"type": "json_object"},
)
seconds = time.perf_counter() - start
text = reply.choices[0].message.content

print("\n--- Raw LLM reply ---")
print(text)

# Step 2: our code has to parse and check the text before it can use it.
try:
    result = json.loads(text)
except json.JSONDecodeError:
    print("\nThe reply is not valid JSON. The code would need to retry.")
    sys.exit(1)

problems = []
if result.get("category") not in ["Office supplies", "IT hardware", "Facilities"]:
    problems.append(f"Unknown category: {result.get('category')}")
if result.get("risk") not in ["Low", "Medium", "High"]:
    problems.append(f"Unknown risk level: {result.get('risk')}")
if not isinstance(result.get("duplicate"), bool):
    problems.append(f"Duplicate is not true or false: {result.get('duplicate')}")

print("\n--- What our code can use ---")
if problems:
    print("The reply needs a retry:")
    for problem in problems:
        print(f"  {problem}")
    sys.exit(1)

print(f"Category:   {result['category']}")
print(f"Risk:       {result['risk']}")
print(f"Duplicate:  {result['duplicate']}")
print("Confidence: not provided by the LLM")

# Step 3: decide the next step.
if result["duplicate"] or result["risk"] == "High":
    print("\nDecision: hold payment and send to AP review.")
else:
    print("\nDecision: approve for payment.")

print(f"\nLLM calls: 1   Time: {seconds:.2f} s   Tokens: {reply.usage.total_tokens}")
